# Proyecto Django - Gestión de Libros

## Instrucciones para Ejecutar el Proyecto

1. Clona el repositorio o descarga los archivos.
2. Navega a la carpeta del proyecto.
3. Crea un entorno virtual y actívalo:
   ```bash
   python -m venv venv
   source venv/bin/activate  # En Windows usa `venv\Scripts\activate`